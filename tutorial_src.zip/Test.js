// If you installed snipets, you can automatically generate a functional or class type component as you type "rsc"  or "rcc"

// "rsc"
// import React from 'react';

// const Test = () => {
//     return (
//         <div>

//         </div>
//     );
// };

// export default Test;

// "rcc"
// import React, { Component } from 'react';

// class Test extends Component {
//     render() {
//         return (
//             <div>

//             </div>
//         );
//     }
// }

// export default Test;

import React from "react";
import App from "./App"; //모듈 불러오기

const Test = () => {
  return <App />;
};

export default Test;
