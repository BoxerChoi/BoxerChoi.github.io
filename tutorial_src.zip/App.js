import logo from "./logo.svg";
import "./App.css";
// import React, { Component } from "react";

//아래와 같은 코드는 HTML이 아닌 "JSX 라고 불립니다. 해당 코드는 UI를 보다 쉽게 Rendering 할 수 있도록 돕습니다"
function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>

        {/*주석은 이렇게 작성합니다.*/}
        {/* F1 > "format" > Prettier 선택 시 포맷에 맞게 코드가 자동 정렬됩니다.*/}
        <h1>들여쓰기</h1>

        <h2>들여쓰기2</h2>

        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

// 클래스형 컴포넌트는 위의 함수형 컴포넌트와 비슷하며, state 기능 및 라이프사이클 그리고 임의 메서드를 정의할 수 있다는 차이점이 있습니다.
// class App extends Component {
//   render() {
//     const name = "react";
//     return <div className="react">{name}</div>;
//   }
// }

export default App;
